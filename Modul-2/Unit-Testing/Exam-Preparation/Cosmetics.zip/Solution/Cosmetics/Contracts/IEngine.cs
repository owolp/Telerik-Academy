﻿namespace Cosmetics.Contracts
{
    internal interface IEngine
    {
        void Start();
    }
}
