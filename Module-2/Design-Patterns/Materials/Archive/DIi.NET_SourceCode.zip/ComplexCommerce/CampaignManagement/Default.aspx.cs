﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Ploeh.Samples.Commerce.CampaignPresentation;

namespace Ploeh.Samples.Commerce.Campaign.WebForms
{
    public partial class Default : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
        }
    }
}
