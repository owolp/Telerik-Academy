﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ploeh.Samples.Commerce.UpdateCurrency.CommandLine
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var container = new CurrencyContainer();
            container.ResolveCurrencyParser()
                .Parse(args)
                .Execute();
        }
    }
}
